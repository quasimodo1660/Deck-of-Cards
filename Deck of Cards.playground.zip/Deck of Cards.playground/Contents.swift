//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"

let COLORS=["Blue","Red","Green"]
print (COLORS[0])

struct Card{
    var Color: String
    var Roll:Int
    init(Color:String){
        self.Color=Color
        if self.Color == "Blue"{
            self.Roll = Int(arc4random_uniform(UInt32(2-1+1)))+1
        }
        else if self.Color == "Red"{
            self.Roll = Int(arc4random_uniform(UInt32(4-3+1)))+3
        }
        else{
            self.Roll = Int(arc4random_uniform(UInt32(6-4+1)))+4
        }
        
    }
    
}

class Desk{
    var cards:[Card]=[]
    init(){
        for i in 0..<COLORS.count{
            for _ in 0...9{
                let a = Card(Color:COLORS[i])
                self.cards.append(a)
            }
        }
    }
    func selectCard()->Card{
        let top_most=cards.remove(at: cards.count-1)
        return top_most
    }
    func isEmpty()->Bool{
        if cards.count==0{
            return true
        }
        else{
            return false
        }
    }
    func shuffle(){
        for _ in 0..<cards.count{
            let x = Int(arc4random_uniform(UInt32(cards.count)))
            let y = Int(arc4random_uniform(UInt32(cards.count)))
            let temp = cards[x]
            cards[x] = cards[y]
            cards[y] = temp
        }
    }
}

class Player{
    var name:String
    var hand:[Card]=[]
    init(name:String){
        self.name = name
    }
    func draw(desk:Desk){
        hand.append(desk.selectCard())
    }
    func rollDice()->Int{
        return Int(arc4random_uniform(UInt32(6-1+1)))+1
    }
    func matchingCards(color:String,rollNum:Int)->Int{
        var x = 0
        for i in 0..<hand.count{
            if hand[i].Color == color && hand[i].Roll == rollNum {
                x += 1
            }
        }
        return x
    }
}

var c = Card(Color:"Green")
print(c)
var d = Desk()
print(d.cards)
var liam = Player(name:"Liam")
liam.draw(desk: d)
print(liam.hand.count)


class Game{
    var players:[Player]=[]
    var deck:Desk
    var turnldx:Int
    init(player:[Player],deck:Desk,turnldx:Int=0){
        self.players=player
        self.deck=deck
        self.turnldx=turnldx
        self.deck.shuffle()
    }
    
}













